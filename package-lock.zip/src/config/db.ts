import mongoose, { ConnectOptions, Schema } from "mongoose";
import mongoosePaginate from "mongoose-paginate-v2";


mongoose.plugin(mongoosePaginate);
mongoose.plugin(require("mongoose-autopopulate"));

const connectDB = async () => {
  const { MONGODB_URL } = process.env;

  const con = await mongoose.connect(`${MONGODB_URL}`, {
    useNewUrlParser: true,
    useUnifiedTopology: true,
  } as ConnectOptions);

  console.log(`MongoDB Connected: ${con.connection.host}.`);

  mongoose.connection.on("connecting", () => {
    console.log("Connecting to Database");
  });

  mongoose.connection.on("connected", () => {
    console.log("Mongoose Connected to Database");
  });
  mongoose.connection.on("error", (err) => {
    console.error(err.message);
  });

  mongoose.connection.on("disconnected", () => {
    console.info("Mongoose Connection is Disconnected.");
  });

  process.on("SIGINT", async () => {
    await mongoose.connection.close();
    process.exit(0);
  });
};

export default connectDB;
