import * as mongoose from "mongoose";
import axios from "axios";
import { stringSimilarity } from "../controller/similarity";
import { City } from "../models/city";
import { Country } from "../models/country";
const {
  GETAROOM_SEARCH_API,
  GETAROOM_API_KEY,
  GETAROOM_AUTH_TOKEN,
  GETAROOM_PROPERTIES_API,
} = process.env;
import xml2js from "xml2js";

import csvtojson from "csvtojson";
import Hotel from "../models/hotel";

const seedHotelsId = async () => {
  const properties = await axios
    .get(
      `${GETAROOM_PROPERTIES_API}?api_key=${GETAROOM_API_KEY}&auth_token=${GETAROOM_AUTH_TOKEN}`
    )
    .then((res) => res.data);

  const allpropertiesData = await csvtojson().fromString(properties);

  for (const item of Object.values(allpropertiesData)) {
    const {
      id,
      name,
      street_address,
      latitude,
      longitude,
      locality,
      postal_code,
      country,
    } = item;

    type doc = {
      hotel_id: string;
      hotel_name: string;
      addresses: string;
      location: {
        type: string;
        coordinates: number[];
      };
      city_ref: mongoose.Schema.Types.ObjectId;
      locality: string;
      getaroom_id: string;
      postal_code: string;
    };

    const countryCode = await Country.findOne({
      code: country,
    });

    if (!countryCode) {
      continue;
    }

    const city = await City.findOne({
      country: countryCode._id,
      name: {
        $regex: locality,
        $options: "i",
      },
    });

    if (!city) {
      continue;
    }

    const newHotelDoc = {
      hotel_id: id,
      hotel_name: name,
      addresses: street_address,
      location: {
        type: "Point",
        coordinates: [longitude, latitude],
      },
      city_ref: city._id,
      locality,
      getaroom_id: id,
      postal_code,
    };

    const foundHotelDoc: any = await Hotel.findOne({
      city_ref: city._id,
      location: {
        $near: {
          $geometry: {
            type: "point",
            coordinates: [longitude, latitude],
          },
          $maxDistance: 1000,
          $minDistance: 0,
        },
      },
    });

    let flag = true;

    const similarity = stringSimilarity(
      newHotelDoc.hotel_name,
      foundHotelDoc?.hotel_name || ""
    );
    console.log("hotel getaroom ", newHotelDoc.hotel_name);
    console.log("Hotel Db ", foundHotelDoc?.hotel_name);
    console.log(similarity);

    similarity < 0.5 ? (flag = false) : (flag = true);

    if (flag) {
      foundHotelDoc.getaroom_id = id;
      await foundHotelDoc.save();
    } else {
      await Hotel.create(newHotelDoc);
    }
  }
  console.log("data seeded");
  mongoose.connection.close();
};

export default seedHotelsId;
